<?php

$h=(int)date('G',time());
$m=date('i',time());


if (timeIs("02:00") {
	sync_favorit();
}




