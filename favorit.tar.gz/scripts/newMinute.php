<?php

$h=(int)date('G',time());
$m=date('i',time());

// Запускаем синхронизацию файлов
if (timeIs("02:00") {
	sync_favorit();
}

// Очищаем историю
if (timeIs("03:00") {
	clear_history();
}

// Делаем бэкап базы данных
if (timeIs("04:30") {
	backup_majordomo("db");
}

// Каждые 10 минут контролируем размеры папок
if (($m%10)==0) {
$folder=ROOT.'cms/debmes';
$foldersize=dirsize($folder);
	if ($foldersize>10*1024)
	{
	say("Внимание! Папка ".$folder." занимает ".$foldersize."Kb"." запускаю очистку",2);
	clear_files($folder,7,1);
	}
}




